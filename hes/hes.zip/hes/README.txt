List the "user-agent" string and 'common name' of the two browsers you used to test your work

You can get the User-Agent string from:  https://cscie12.dce.harvard.edu/browser.html

The for the 'common name', give us the Browser Name (e.g. Chrome, Firefox, Edge, Safari) and operating system (e.g. Windows, Mac, Linux).

As an example, if I were to answer this for the browser I am currently using, it would be:
* Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36
* Chrome, Mac

Your Answers for the two browsers you are using:

1.


2. 


